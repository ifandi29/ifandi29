import a23_0xc43b82 from "react";
import { render } from "ink";
import a23_0x189dc0 from "./components/startBotComponent.js";
async function StartBot(_0x13dcfb, _0x1f0422, _0x385da3) {
  return new Promise(_0x4ac791 => {
    let _0x37b36c;
    const {
      waitUntilExit: _0x55cbe1
    } = render(a23_0xc43b82.createElement(a23_0x189dc0, {
      accounts: _0x13dcfb,
      banner: _0x1f0422,
      validateLicenseKey: _0x385da3,
      onChange: _0x46eb32 => {
        _0x37b36c = _0x46eb32;
        _0x4ac791(_0x37b36c);
      }
    }));
    _0x55cbe1();
  });
}
export default StartBot;