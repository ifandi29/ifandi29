const ALIAS = "monyetkontol";
const VERSION_SC = 1;
const SERVER_SC = "kontolmonyet";
const DIR_PATH_SESSION = ".monyett";
export { ALIAS, VERSION_SC, SERVER_SC, DIR_PATH_SESSION };