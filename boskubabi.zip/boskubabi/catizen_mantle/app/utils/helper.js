import a26_0x271bad from "os";
import a26_0x5e67db from "fs";
import a26_0x1d5b52 from "path";
import a26_0x4caf1b from "crypto";
import a26_0x248e76 from "chalk";
import { promisify } from "util";
import { writeFile, readFile } from "fs";
import { exec } from "child_process";
import { promisified } from "regedit";
import a26_0x253d12 from "axios";
import { v4 as a26_0x3e29aa } from "uuid";
import { ALIAS, VERSION_SC } from "./konst.js";
const promisifiedRegedit = promisified;
const writeFileAsync = promisify(writeFile);
const readFileAsync = promisify(readFile);
const execPromise = promisify(exec);
const getOrdinalSuffix = _0x3a06ba => {
  const _0x4ff9b0 = _0x3a06ba % 10;
  const _0x38df38 = _0x3a06ba % 100;
  if (_0x4ff9b0 === 1 && _0x38df38 !== 11) {
    return _0x3a06ba + "st";
  }
  if (_0x4ff9b0 === 2 && _0x38df38 !== 12) {
    return _0x3a06ba + "nd";
  }
  if (_0x4ff9b0 === 3 && _0x38df38 !== 13) {
    return _0x3a06ba + "rd";
  }
  return _0x3a06ba + "th";
};
const formatDate = _0x25995b => {
  const _0x4f1793 = new Date(Math.floor(_0x25995b * 1000));
  let _0x938c3a = _0x4f1793.getDate();
  let _0x3dcb1a = _0x4f1793.getMonth() + 1;
  let _0xab0e90 = _0x4f1793.getFullYear();
  if (_0x938c3a < 10) {
    _0x938c3a = "0" + _0x938c3a;
  }
  if (_0x3dcb1a < 10) {
    _0x3dcb1a = "0" + _0x3dcb1a;
  }
  const _0x1c7f31 = _0xab0e90.toString().slice(-2);
  return _0x938c3a + "/" + _0x3dcb1a + "/" + _0x1c7f31;
};
const countdownLicense = _0x59deeb => {
  const _0x2aed68 = Date.now();
  let _0x469105 = Math.floor(_0x59deeb * 1000) - _0x2aed68;
  if (_0x469105 <= 0) {
    return "license Expired";
  }
  const _0x3c44a4 = 60000;
  const _0x1bf30f = _0x3c44a4 * 60;
  const _0x231e6a = _0x1bf30f * 24;
  const _0xac21d9 = Math.floor(_0x469105 / _0x231e6a);
  _0x469105 %= _0x231e6a;
  const _0x2ed48c = Math.floor(_0x469105 / _0x1bf30f);
  _0x469105 %= _0x1bf30f;
  const _0x47d7ef = Math.floor(_0x469105 / _0x3c44a4);
  return _0xac21d9 + " hari " + _0x2ed48c + " jam " + _0x47d7ef + " menit";
};
const convertTimestamp = _0x333000 => {
  if (_0x333000 < 1) {
    _0x333000 = 0;
  }
  const _0x475baa = Math.floor(_0x333000 / 3600);
  const _0x5e0b38 = Math.floor(_0x333000 % 3600 / 60);
  const _0x39a815 = _0x333000 % 60;
  const _0x120412 = _0x475baa.toString().padStart(2, "0");
  const _0x3dd8cd = _0x5e0b38.toString().padStart(2, "0");
  const _0x4ff35d = _0x39a815.toString().padStart(2, "0");
  return "" + a26_0x248e76.magentaBright("[") + a26_0x248e76.whiteBright(_0x120412) + a26_0x248e76.blackBright(":") + a26_0x248e76.whiteBright(_0x3dd8cd) + a26_0x248e76.blackBright(":") + a26_0x248e76.whiteBright(_0x4ff35d) + a26_0x248e76.magentaBright("]");
};
const getCurrentTime = () => {
  const _0x321989 = new Date();
  const _0x1f71c5 = _0x321989.getHours().toString().padStart(2, "0");
  const _0x1d3c1e = _0x321989.getMinutes().toString().padStart(2, "0");
  const _0x36f3f1 = _0x321989.getSeconds().toString().padStart(2, "0");
  return "" + a26_0x248e76.magentaBright("[") + a26_0x248e76.whiteBright(_0x1f71c5) + a26_0x248e76.blackBright(":") + a26_0x248e76.whiteBright(_0x1d3c1e) + a26_0x248e76.blackBright(":") + a26_0x248e76.whiteBright(_0x36f3f1) + a26_0x248e76.magentaBright("]");
};
const formatNumber = _0x4e0b53 => {
  const _0x3bccd2 = ["", "K", "M", "B", "T", "Q"];
  const _0x354afc = "abcdefghijklmnopqrstuvwxyz";
  if (_0x4e0b53 < 1000) {
    return _0x4e0b53.toString();
  }
  let _0x24a0ab = -1;
  let _0x5723cc = _0x4e0b53;
  while (_0x5723cc >= 1000) {
    _0x5723cc /= 1000;
    _0x24a0ab++;
  }
  if (_0x24a0ab >= _0x3bccd2.length) {
    const _0x5df57b = _0x24a0ab - _0x3bccd2.length;
    const _0x2e8db0 = _0x354afc[Math.floor(_0x5df57b / _0x354afc.length)];
    const _0xe61166 = _0x354afc[_0x5df57b % _0x354afc.length];
    return "" + _0x5723cc.toFixed(3) + _0x2e8db0 + _0xe61166;
  }
  return "" + _0x5723cc.toFixed(3) + _0x3bccd2[_0x24a0ab];
};
const sha1Hash = _0x553e28 => {
  const _0x355b41 = a26_0x4caf1b.createHash("sha1");
  _0x355b41.update(_0x553e28);
  return _0x355b41.digest("hex");
};
const validateLicense = async _0x4e7269 => {
  try {
    const _0x29483a = await a26_0x253d12.post("https://tuyulgaple.my.id/premium/", {
      request: ALIAS,
      tipe: "verif",
      userid: _0x4e7269
    });
    return _0x29483a.data;
  } catch (_0x2205a8) {
    return {
      code: 100,
      data: null
    };
  }
};
const getWindowsProductId = async () => {
  try {
    const {
      stdout: _0x156d06,
      stderr: _0x3bf272
    } = await execPromise("powershell.exe \"(Get-WmiObject Win32_ComputerSystemProduct).UUID\"");
    if (_0x3bf272) {
      return null;
    }
    const _0x39d500 = _0x156d06.trim();
    return _0x39d500;
  } catch (_0xd66800) {
    return null;
  }
};
const generateLicenseTermux = async () => {
  try {
    await execPromise("termux-keystore generate " + ALIAS + " -a RSA");
    const {
      stdout: _0x89f957,
      stderr: _0x240d02
    } = await execPromise("termux-keystore list -d");
    if (_0x240d02) {
      throw new Error("Termux API not installed");
    }
    let _0x5002a1 = null;
    try {
      const _0x4ff3a6 = JSON.parse(_0x89f957.trim());
      if (_0x4ff3a6.length > 0) {
        _0x4ff3a6.forEach(_0x21ec35 => {
          if (_0x21ec35.alias === ALIAS) {
            _0x5002a1 = sha1Hash(_0x21ec35.modulus);
          }
        });
      }
    } catch (_0x1e6a6f) {
      throw new Error("Failed parsing license data");
    }
    if (!_0x5002a1) {
      throw new Error("Failed generating license key");
    }
    return _0x5002a1;
  } catch (_0x561192) {
    throw new Error("Failed generating license: " + _0x561192.message);
  }
};
const getLicenseTermux = async () => {
  try {
    const {
      stdout: _0x4d0d60,
      stderr: _0x32d302
    } = await execPromise("termux-keystore list -d");
    if (_0x32d302) {
      throw new Error("Termux API not installed");
    }
    let _0x7c8133 = null;
    try {
      const _0x362b30 = JSON.parse(_0x4d0d60.trim());
      if (_0x362b30.length > 0) {
        _0x362b30.forEach(_0x5a4707 => {
          if (_0x5a4707.alias === ALIAS) {
            _0x7c8133 = sha1Hash(_0x5a4707.modulus);
          }
        });
      }
    } catch (_0x42c047) {
      throw new Error("Failed parsing license data");
    }
    if (!_0x7c8133) {
      _0x7c8133 = await generateLicenseTermux();
    }
    return _0x7c8133;
  } catch (_0x19a807) {
    throw new Error("Failed getting license: " + _0x19a807.message);
  }
};
const getRegeditProductId = async () => {
  try {
    const _0x2db739 = await promisifiedRegedit.list(["HKCU\\SOFTWARE\\CatizenPremium"]);
    if (_0x2db739["HKCU\\SOFTWARE\\CatizenPremium"].exists) {
      const _0x28ebdc = _0x2db739["HKCU\\SOFTWARE\\CatizenPremium"].values.uuid;
      if (!_0x28ebdc) {
        const _0x4ca663 = a26_0x3e29aa();
        await promisifiedRegedit.putValue({
          "HKCU\\SOFTWARE\\CatizenPremium": {
            uuid: {
              value: _0x4ca663,
              type: "REG_SZ"
            }
          }
        });
        return _0x4ca663;
      }
      if (_0x28ebdc && typeof _0x28ebdc.value === "string") {
        return _0x28ebdc.value;
      } else {
        throw new Error("Invalid UUID format in registry");
      }
    } else {
      const _0x352917 = a26_0x3e29aa();
      await promisifiedRegedit.createKey(["HKCU\\SOFTWARE\\CatizenPremium"]);
      await promisifiedRegedit.putValue({
        "HKCU\\SOFTWARE\\CatizenPremium": {
          uuid: {
            value: _0x352917,
            type: "REG_SZ"
          }
        }
      });
      return _0x352917;
    }
  } catch (_0x54d341) {
    throw new Error("Failed while managing registry: " + _0x54d341.message);
  }
};
const getLicenseWindows = async () => {
  try {
    const _0x4e287d = await getWindowsProductId();
    let _0x43935d = null;
    if (_0x4e287d) {
      _0x43935d = sha1Hash(_0x4e287d + "|" + ALIAS);
    } else {
      const _0x3eb009 = await getRegeditProductId();
      _0x43935d = sha1Hash(_0x3eb009 + "|" + ALIAS);
    }
    return _0x43935d;
  } catch (_0x2ca2ce) {
    throw new Error("Failed while generating license: " + _0x2ca2ce.message);
  }
};
const getLinuxMachineId = async () => {
  try {
    const {
      stdout: _0x2650d6,
      stderr: _0x571b2c
    } = await execPromise("hostnamectl status | grep \"Machine ID\"");
    if (_0x571b2c) {
      throw new Error("Failed to get machine ID");
    }
    const _0x400e2f = _0x2650d6.trim().split(":");
    if (_0x400e2f.length < 2) {
      throw new Error("Invalid machine ID format");
    }
    const _0x57d39d = _0x400e2f[1].trim();
    return _0x57d39d;
  } catch (_0x4aa051) {
    throw new Error("Failed to get machine ID: " + _0x4aa051.message);
  }
};
const getOrCreateLinuxUUID = async () => {
  const _0x4611be = "/var/lib/" + ALIAS + ".txt";
  try {
    let _0x206faf;
    try {
      const _0x815e50 = await readFileAsync(_0x4611be, "utf8");
      _0x206faf = _0x815e50.trim();
    } catch (_0x595692) {
      _0x206faf = a26_0x3e29aa();
      await writeFileAsync(_0x4611be, _0x206faf, "utf-8");
    }
    return _0x206faf;
  } catch (_0x419b65) {
    throw new Error("Failed while managing UUID file: " + _0x419b65.message);
  }
};
const getLinuxProductId = async () => {
  try {
    const _0x4081dc = await getLinuxMachineId();
    const _0x175ef9 = _0x4081dc ? _0x4081dc : await getOrCreateLinuxUUID();
    return _0x175ef9;
  } catch (_0x3d436c) {
    throw new Error("Failed while managing UUID or Machine ID: " + _0x3d436c.message);
  }
};
const getLicenseUbuntu = async () => {
  try {
    const _0x48b8ff = await getLinuxProductId();
    const _0x5dea4c = sha1Hash(_0x48b8ff + "|" + ALIAS);
    return _0x5dea4c;
  } catch (_0x103bda) {
    throw new Error("Failed while generating license: " + _0x103bda.message);
  }
};
const getLicense = async () => {
  let _0x17de5c = null;
  if (a26_0x271bad.platform() === "win32") {
    _0x17de5c = await getLicenseWindows();
  } else if (a26_0x271bad.platform() === "android") {
    _0x17de5c = await getLicenseTermux();
  } else if (a26_0x271bad.platform() === "linux") {
    _0x17de5c = await getLicenseUbuntu();
  } else {
    throw new Error("This program not support for " + a26_0x271bad.platform() + " yet");
  }
  return _0x17de5c;
};
const getSessionDirectory = () => {
  // Menggunakan direktori kerja saat ini sebagai basis
  const sessionDir = a26_0x1d5b52.join(process.cwd(), "session");

  return sessionDir;
};

const createSessionDirectory = () => {
  const sessionDirectory = getSessionDirectory();
  
  if (!a26_0x5e67db.existsSync(sessionDirectory)) {
    a26_0x5e67db.mkdirSync(sessionDirectory, {
      recursive: true
    });
  }
  
  return sessionDirectory;  // Kembalikan path direktori sesi yang baru dibuat
};
const runtimeServer = async () => {
    try {
      // Default behavior or some alternative logic can be implemented here
      return {
        status: "connect",
        baner: baner(), // Use the existing banner function or create a default banner
      };
    } catch (_0x19be52) {
      return {
        status: "reconnecting",
        baner: baner(),
      };
    }
  };
  
const baner = () => {
  const _0x3f6b27 = "\n" + a26_0x248e76.white("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~") + "\n" + a26_0x248e76.blueBright("╔══╗ ╔╦╗ ╔═╦╗ ╔╦╗ ╔╗─ ╔══╗ ╔══╗ ╔═╗ ╔╗─ ╔═╗") + "\n" + a26_0x248e76.blueBright("╚╗╔╝ ║║║ ╚╗║║ ║║║ ║║─ ║╔═╣ ║╔╗║ ║╬║ ║║─ ║╦╝") + "\n" + a26_0x248e76.whiteBright("─║║─ ║║║ ╔╩╗║ ║║║ ║╚╗ ║╚╗║ ║╠╣║ ║╔╝ ║╚╗ ║╩") + "\n" + a26_0x248e76.cyanBright("─╚╝─ ╚═╝ ╚══╝ ╚═╝ ╚═╝ ╚══╝ ╚╝╚╝ ╚╝─ ╚═╝ ╚═╝") + "\n" + a26_0x248e76.whiteBright("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~") + "\n" + a26_0x248e76.whiteBright("- skrip") + a26_0x248e76.blueBright("[" + ALIAS + "]") + " " + a26_0x248e76.whiteBright("Versi : " + VERSION_SC) + "\n" + a26_0x248e76.redBright("- tidak dapat terhubung ke server") + " " + a26_0x248e76.blueBright("tuyulgaple") + "\n";
  return _0x3f6b27;
};

const writeToFile = async (_0x3c6d49, _0x45acaf) => {
  await writeFileAsync(_0x3c6d49, _0x45acaf, "utf-8");
};
const readJsonFile = _0x1865fe => {
  try {
    const _0x126686 = a26_0x5e67db.readFileSync(_0x1865fe, "utf8");
    return JSON.parse(_0x126686);
  } catch (_0x4e0c1c) {
    return null;
  }
};
const deleteFile = _0x37ab58 => {
  try {
    a26_0x5e67db.unlinkSync(_0x37ab58);
    return {
      status: true,
      message: "File deleted successfully"
    };
  } catch (_0x39a95c) {
    return {
      status: false,
      message: "Error deleting the file"
    };
  }
};
const getAllFilesFromFolder = _0x1c6ed2 => {
  let _0x20fe66 = [];
  function _0x5e6e71(_0x371173) {
    const _0x5eff33 = a26_0x5e67db.readdirSync(_0x371173);
    _0x5eff33.forEach(_0x3d9e54 => {
      const _0x4434a7 = a26_0x1d5b52.join(_0x371173, _0x3d9e54);
      const _0x532954 = a26_0x5e67db.statSync(_0x4434a7);
      if (_0x532954 && _0x532954.isDirectory()) {
        _0x5e6e71(_0x4434a7);
      } else {
        _0x20fe66.push(_0x4434a7);
      }
    });
  }
  _0x5e6e71(getSessionDirectory(_0x1c6ed2));
  return _0x20fe66;
};
const groupAccounts = (_0x960d03, _0x533f00) => {
  const _0x5d4a6a = [];
  for (let _0x19a031 = 0; _0x19a031 < _0x960d03.length; _0x19a031 += _0x533f00) {
    _0x5d4a6a.push(_0x960d03.slice(_0x19a031, _0x19a031 + _0x533f00));
  }
  return _0x5d4a6a;
};
const getUserFromUrl = _0x4ca1ce => {
  const _0x15fc72 = new URLSearchParams(_0x4ca1ce);
  const _0x50e026 = _0x15fc72.get("user");
  if (!_0x50e026) {
    throw new Error("Parameter 'user' tidak ditemukan di URL");
  }
  const _0x1179f1 = decodeURIComponent(_0x50e026);
  const _0x5dd449 = JSON.parse(_0x1179f1);
  return _0x5dd449;
};
export { getOrdinalSuffix, convertTimestamp, getCurrentTime, formatNumber, validateLicense, getLicense, createSessionDirectory, getSessionDirectory, getAllFilesFromFolder, writeToFile, readJsonFile, deleteFile, runtimeServer, groupAccounts, getUserFromUrl, formatDate, countdownLicense };