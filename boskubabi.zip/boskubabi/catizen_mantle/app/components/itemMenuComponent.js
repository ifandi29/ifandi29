import a3_0x4b9a47 from "react";
import { Text, useFocus } from "ink";
import a3_0x589217 from "chalk";
const ItemMenuComponent = ({
  label: _0x2031d8,
  id: _0x3cfc94
}) => {
  const {
    isFocused: _0x3b2d19
  } = useFocus({
    id: _0x3cfc94
  });
  if (_0x3b2d19) {
    return a3_0x4b9a47.createElement(Text, {
      inverse: true,
      color: "white",
      bold: true
    }, "[", _0x3cfc94, "] ", _0x2031d8);
  } else {
    return a3_0x4b9a47.createElement(Text, {
      color: "greenBright",
      bold: true
    }, a3_0x589217.magentaBright("[") + a3_0x589217.blackBright(_0x3cfc94) + a3_0x589217.magentaBright("] "), _0x2031d8);
  }
};
export default ItemMenuComponent;