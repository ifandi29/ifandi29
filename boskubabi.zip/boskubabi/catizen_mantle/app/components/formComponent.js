import { Box, Text } from "ink";
import a2_0xe2d52f from "react";
import a2_0x511002 from "../hooks/useForm.js";
import a2_0x4bf360 from "ink-spinner";
const FormComponent = ({
  banner: _0x1325e7,
  name: _0x487f37,
  onChange: _0x1679ea
}) => {
  const {
    value: _0x25a7d1,
    isLoading: _0x2722d5
  } = a2_0x511002({
    onChange: _0x1679ea,
    name: _0x487f37
  });
  return a2_0xe2d52f.createElement(Box, {
    flexDirection: "column"
  }, a2_0xe2d52f.createElement(Text, null), a2_0xe2d52f.createElement(Box, {
    marginBottom: 1
  }, a2_0xe2d52f.createElement(Text, {
    color: "greenBright"
  }, _0x487f37, " ", _0x2722d5 && a2_0xe2d52f.createElement(a2_0x4bf360, null))), a2_0xe2d52f.createElement(Text, null, _0x25a7d1));
};
export default FormComponent;