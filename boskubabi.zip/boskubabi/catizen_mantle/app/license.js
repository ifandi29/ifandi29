import a21_0x4e20f7 from "chalk";

const License = async () => {
  
  console.log(a21_0x4e20f7.greenBright("License check bypassed. Continuing..."));
  
  return {
    code: 200,
    data: {
      exp: "UNLIMITED" // Menampilkan "UNLIMITED" sebagai nilai expire
    }
  };
};

export default License;
