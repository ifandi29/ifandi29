import { useFocusManager, useInput } from "ink";
import { useEffect, useState } from "react";
import { groupAccounts } from "../utils/helper.js";

const useStartBot = ({
  accounts: _0x4f4545,
  validateLicenseKey: _0x29e826,
  onChange: _0x48dbe5
}) => {
  const { focus: _0x4752ad } = useFocusManager();
  const [_0x1e7db1, _0x31ad57] = useState(0);
  const [_0x2997a3, _0x56e4d0] = useState([]);
  const [_0x459a92, _0x3179a7] = useState({
    status: "connect",
    baner: ""
  });

  // Define _0xc8b70d here
  const _0xc8b70d = {
    status: "connect", // Initialize the status or any other properties as needed
    // add other properties if necessary
  };

  const _0x4b6ede = (_0x5479b9) => {
    if (_0x5479b9 > _0x2997a3.length) {
      _0x31ad57(1);
    } else if (_0x5479b9 < 1) {
      _0x31ad57(_0x2997a3.length);
    } else {
      _0x31ad57(_0x5479b9);
    }
  };

  useInput((_0x4ea44a, _0x39c4f5) => {
    if (_0x4ea44a) {
      try {
        let _0x289216 = parseInt(_0x4ea44a);
        if (_0x289216 <= _0x2997a3.length) {
          _0x31ad57(_0x289216);
        }
      } catch (_0x4b2f45) {}
    }
    if (_0x39c4f5.upArrow) {
      _0x4b6ede(_0x1e7db1 - 1);
    }
    if (_0x39c4f5.downArrow) {
      _0x4b6ede(_0x1e7db1 + 1);
    }
    if (_0x39c4f5.leftArrow) {
      _0x4b6ede(_0x1e7db1 - 1);
    }
    if (_0x39c4f5.rightArrow) {
      _0x4b6ede(_0x1e7db1 + 1);
    }
    if (_0x39c4f5.escape) {
      _0x48dbe5("back");
    }
    if (_0x4ea44a === "q") {
      _0x48dbe5("exit");
    }
  });

  useEffect(() => {
    const _0x3964a1 = async () => {
      if (_0x459a92.status === "reconnecting") {
        if (_0xc8b70d.status === "exit") {
          _0x48dbe5("exit");
        }
        _0x3179a7(_0xc8b70d);
      }
    };
    const _0x436527 = setInterval(_0x3964a1, 5000);
    return () => {
      clearInterval(_0x436527);
    };
  }, [_0x459a92]);

  useEffect(() => {
    const _0x5c90f1 = async () => {
      if (_0x459a92.status === "connect") {
        if (_0xc8b70d.status === "exit") {
          _0x48dbe5("exit");
        }
        _0x3179a7(_0xc8b70d);
      }
      if (Math.floor(Date.now() / 1000) >= _0x29e826.data.exp) {
        process.exit();
      }
    };
    const _0x230c47 = setInterval(_0x5c90f1, 60000);
    return () => {
      clearInterval(_0x230c47);
    };
  }, [_0x459a92]);

  useEffect(() => {
    if (_0x2997a3.length < 1) {
      const _0x5bafb4 = groupAccounts(_0x4f4545, 1);
      _0x56e4d0(_0x5bafb4);
      _0x31ad57(1);
    }
  }, [_0x2997a3]);

  useEffect(() => {
    _0x4752ad(_0x1e7db1.toString());
  }, [_0x1e7db1]);

  return {
    pageAccount: _0x2997a3,
    runtimeStatus: _0x459a92,
    focusOn: _0x1e7db1
  };
};

export default useStartBot;
