import a7_0x320b20 from "react";
import a7_0x35cdea from "./components/deleteAccountComponent.js";
import { render } from "ink";
async function DeleteAccount(_0x48a317, _0x2f7fba) {
  return new Promise(_0x541b6d => {
    let _0x4a7179;
    const {
      waitUntilExit: _0x38b0d7
    } = render(a7_0x320b20.createElement(a7_0x35cdea, {
      accounts: _0x48a317,
      banner: _0x2f7fba,
      onChange: _0x3a4685 => {
        _0x4a7179 = _0x3a4685;
        _0x541b6d(_0x4a7179);
      }
    }));
    _0x38b0d7();
  });
}
export default DeleteAccount;