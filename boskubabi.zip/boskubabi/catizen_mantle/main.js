import chalk from "chalk";
import fs from "fs"; // Tambahkan ini untuk membaca file
import {
  createSessionDirectory,
  getAllFilesFromFolder,
  getSessionDirectory,
  getUserFromUrl,
  readJsonFile,
  runtimeServer,
  writeToFile
} from "./app/utils/helper.js";
import { DIR_PATH_SESSION } from "./app/utils/konst.js";
import showMenu from "./app/form.js";
import deleteAccount from "./app/deleteAccount.js";
import mainMenu from "./app/mainMenu.js";
import Catizen from "./app/libs/catizen.js";
import licenseCheck from "./app/license.js";
import startBot from "./app/startBot.js";

createSessionDirectory(DIR_PATH_SESSION);

(async () => {
  let serverStatus = await runtimeServer();
  if (serverStatus.status === "exit") {
    process.exit();
  }

  let retryCount = 0;
  const maxRetries = 10;

  while (serverStatus.status === "reconnecting" && retryCount < maxRetries) {
    retryCount++;
    console.clear();
    console.log(chalk.yellowBright("Menghubungkan kembali ") + chalk.whiteBright("•".repeat(retryCount)));
    console.log(`Percobaan ${retryCount}: Status Saat Ini - ${serverStatus.status}`);

    if (retryCount > 4) {
      retryCount = 0;
    }

    serverStatus = await runtimeServer();
    console.log(`Percobaan ${retryCount}: Status Baru - ${serverStatus.status}`);
    await new Promise(resolve => setTimeout(resolve, 5000));
  }

  if (serverStatus.status === "reconnecting") {
    console.log(chalk.redBright("Gagal menghubungkan kembali setelah beberapa kali percobaan."));
    process.exit();
  }

  console.clear();
  const license = await licenseCheck();
  console.clear();

  while (true) {
    const userChoice = await mainMenu(serverStatus.banner);

    if (userChoice === "exit") {
      process.exit();
    }

    if (userChoice === "1") {
      const sessionFiles = getAllFilesFromFolder(DIR_PATH_SESSION);
      let sessionData = [];

      for (let file of sessionFiles) {
        if (file) {
          const fileData = readJsonFile(file);
          sessionData.push(fileData);
        }
      }

      if (sessionFiles.length < 1) {
        await showMenu(chalk.yellowBright("Akun kosong, silakan tambahkan akun sebelum memulai bot") + "\n" + chalk.blackBright("Tekan Enter untuk Kembali"), serverStatus.banner);
      } else {
        const botResponse = await startBot(sessionData, serverStatus.banner, license);
        if (botResponse === "exit") {
          process.exit();
        }
      }
    }

    if (userChoice === "2") {
      // Minta nama file yang berisi init_data secara massal
      const fileName = await showMenu("Masukkan NamaFile Query:", serverStatus.banner);

      // Baca isi file
      let initDataList;
      try {
        const fileContent = fs.readFileSync(fileName, "utf-8");
        initDataList = fileContent.split("\n").map(line => line.trim()).filter(line => line.length > 0);
      } catch (error) {
        await showMenu(chalk.redBright("Gagal membaca file. Silakan periksa jalur file dan coba lagi.") + "\n" + chalk.blackBright("Tekan Enter untuk Kembali"), serverStatus.banner);
        continue;
      }

      let successCount = 0; // Variabel penghitung akun yang berhasil dimasukkan

      for (const initData of initDataList) {
        let userInfo;

        try {
          userInfo = getUserFromUrl(initData);
        } catch (error) {
          console.log(chalk.yellowBright(`Melewatkan init_data tidak valid: ${initData}`));
          continue;
        }

        // Menghapus penggunaan proxy, langsung menyimpan data akun
        const catizenInstance = new Catizen({ token: "", initData: initData });
        const loginResult = await catizenInstance.login();

        if ("code" in loginResult) {
          if (loginResult.code === 106) {
            console.log(chalk.redBright(`Catizen sedang dalam pemeliharaan untuk init_data: ${initData}`));
          } else if (loginResult.code === 2) {
            console.log(chalk.redBright(`Kredensial tidak valid untuk init_data: ${initData}`));
          }
        } else {
          try {
            // Simpan data akun tanpa konfigurasi proxy
            writeToFile(getSessionDirectory(DIR_PATH_SESSION) + "/" + userInfo.username + ".json", JSON.stringify({
              username: userInfo.username,
              access_token: "",
              init_data: initData,
              use_proxy: false,
              proxy_hostname: "",
              proxy_protocol: "socks5",
              proxy_port: 0,
              proxy_username: "",
              proxy_password: ""
            }));
            console.log(chalk.greenBright(`Berhasil Menambahkan Login untuk ${userInfo.username}`));
            successCount++; // Increment counter jika berhasil
          } catch (error) {
            console.log(chalk.redBright(`Gagal menyimpan akun untuk init_data: ${initData}`));
          }
        }

        // Tambahkan delay 5 detik setelah memproses setiap akun
        console.log(chalk.blueBright(`Menunggu selama 5 detik sebelum memproses akun berikutnya...`));
        await new Promise(resolve => setTimeout(resolve, 5000));
      }

      // Tampilkan jumlah akun yang berhasil dimasukkan
      await showMenu(chalk.greenBright(`Penambahan akun massal selesai. ${successCount} akun berhasil ditambahkan.`) + "\n" + chalk.blackBright("Tekan Enter untuk Kembali"), serverStatus.banner);
    }

    if (userChoice === "3") {
      try {
        const sessionFiles = getAllFilesFromFolder(DIR_PATH_SESSION);
        let accounts = [];

        for (let file of sessionFiles) {
          if (file) {
            const fileData = readJsonFile(file);
            accounts.push({ name: fileData.username, location: file });
          }
        }

        if (accounts.length > 0) {
          const deleteResponse = await deleteAccount(accounts, serverStatus.banner);
          if (deleteResponse === "exit") {
            process.exit();
          }
        } else {
          await showMenu(chalk.redBright("Akun kosong") + "\n" + chalk.blackBright("Tekan Enter untuk Kembali"), serverStatus.banner);
          continue;
        }
      } catch (error) {
        await showMenu(chalk.redBright("Terjadi kesalahan") + "\n" + chalk.blackBright("Tekan Enter untuk Kembali"), serverStatus.banner);
        continue;
      }
    }
  }
})();
