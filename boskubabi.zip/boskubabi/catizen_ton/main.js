import chalk from 'chalk'; // For colored console output.
import fs from 'fs'; // To handle file operations.
import { 
  createSessionDirectory, 
  getAllFilesFromFolder, 
  getSessionDirectory, 
  getUserFromUrl, 
  readJsonFile, 
  runtimeServer, 
  updateBanner, 
  writeToFile 
} from './app/utils/helper.js'; // Utility functions.
import { DIR_PATH_SESSION } from './app/utils/konst.js'; // Constant for session directory path.
import form from './app/form.js'; // Handles form interactions.
import deleteAccount from './app/deleteAccount.js'; // Handles account deletion.
import mainMenu from './app/mainMenu.js'; // Handles the main menu interactions.
import proxyManager from './app/libs/proxyManager.js'; // Manages proxy connections.
import Catizen from './app/libs/catizen.js'; // Likely an API or library related to "Catizen".
import license from './app/license.js'; // Handles license checks.
import startBot from './app/startBot.js'; // Starts a bot session.

// Create the session directory if it doesn't exist.
createSessionDirectory(DIR_PATH_SESSION);

(async () => {
  // Start the server and check its status.
  let serverStatus = await runtimeServer();
  if (serverStatus.status === "exit") {
    process.stdout.write(updateBanner(serverStatus.banner || ''));
    process.exit();
  }

  let reconnectAttempts = 0;

  // Handle reconnections if the server is in reconnecting status.
  while (serverStatus.status === 'reconnecting') {
    reconnectAttempts++;
    process.stdout.write("\x1Bc"); // Clears the console.
    process.stdout.write(updateBanner(serverStatus.banner || ''));
    console.log(chalk.yellowBright("Reconnecting ") + chalk.whiteBright('•'.repeat(reconnectAttempts)));
    if (reconnectAttempts > 4) {
      reconnectAttempts = 0;
    }
    serverStatus = await runtimeServer();
    await new Promise(resolve => setTimeout(resolve, 5000)); // Wait 5 seconds before trying again.
  }

  process.stdout.write("\x1Bc");
  process.stdout.write(updateBanner(serverStatus.banner || ''));

  // Check the license status.
  const licenseStatus = await license();
  process.stdout.write("\x1Bc");

  // Main loop to handle menu interactions.
  while (true) {
    const menuOption = await mainMenu(serverStatus.banner || '');
    
    // Handle 'exit' option.
    if (menuOption === 'exit') {
      process.exit();
    }

    // Option 1: Start bot with existing sessions.
    if (menuOption === '1') {
      let sessionFiles = getAllFilesFromFolder(DIR_PATH_SESSION);
      let sessionData = [];

      // Read session files and prepare session data.
      for (let i = 0; i < sessionFiles.length; i++) {
        let sessionFile = sessionFiles[i];
        if (sessionFile) {
          let sessionJson = readJsonFile(sessionFile);
          sessionData.push(sessionJson);
        }
      }

      // If no sessions exist, prompt the user to add one.
      if (sessionFiles.length < 1) {
        await form(chalk.yellowBright("Account is empty, please add account before start bot") + "\n" + chalk.blackBright("Press Enter To Back"), serverStatus.banner || '');
      } else {
        const botStartStatus = await startBot(sessionData, serverStatus.banner || '', licenseStatus);
        if (botStartStatus === "exit") {
          process.exit();
        }
      }
    }

    // Option 2: Add a new session using bulk init_data.
    if (menuOption === '2') {
      // Minta nama file yang berisi init_data secara massal
      const fileName = await form("Masukkan NamaFile Query:", serverStatus.banner || '');

      // Baca isi file
      let initDataList;
      try {
        const fileContent = fs.readFileSync(fileName, "utf-8");
        initDataList = fileContent.split("\n").map(line => line.trim()).filter(line => line.length > 0);
      } catch (error) {
        await form(chalk.redBright("Gagal membaca file. Silakan periksa jalur file dan coba lagi.") + "\n" + chalk.blackBright("Tekan Enter untuk Kembali"), serverStatus.banner || '');
        continue;
      }

      let successCount = 0; // Variabel penghitung akun yang berhasil dimasukkan

      for (const initData of initDataList) {
        let userInfo;

        try {
          userInfo = getUserFromUrl(initData);
        } catch (error) {
          console.log(chalk.yellowBright(`Melewatkan init_data tidak valid: ${initData}`));
          continue;
        }

        // Menghapus penggunaan proxy, langsung menyimpan data akun
        const catizenInstance = new Catizen({ token: "", initData: initData });
        const loginResult = await catizenInstance.login();

        if ("code" in loginResult) {
          if (loginResult.code === 106) {
            console.log(chalk.redBright(`Catizen sedang dalam pemeliharaan untuk init_data: ${initData}`));
          } else if (loginResult.code === 2) {
            console.log(chalk.redBright(`Kredensial tidak valid untuk init_data: ${initData}`));
          }
        } else {
          try {
            // Simpan data akun tanpa konfigurasi proxy
            writeToFile(getSessionDirectory(DIR_PATH_SESSION) + "/" + userInfo.username + ".json", JSON.stringify({
              username: userInfo.username,
              access_token: "",
              init_data: initData,
              use_proxy: false,
              proxy_hostname: "",
              proxy_protocol: "socks5",
              proxy_port: 0,
              proxy_username: "",
              proxy_password: ""
            }));
            console.log(chalk.greenBright(`Berhasil Menambahkan Login untuk ${userInfo.username}`));
            successCount++; // Increment counter jika berhasil
          } catch (error) {
            console.log(chalk.redBright(`Gagal menyimpan akun untuk init_data: ${initData}`));
          }
        }

        // Tambahkan delay 5 detik setelah memproses setiap akun
        console.log(chalk.blueBright(`Menunggu selama 5 detik sebelum memproses akun berikutnya...`));
        await new Promise(resolve => setTimeout(resolve, 5000));
      }

      // Tampilkan jumlah akun yang berhasil dimasukkan
      await form(chalk.greenBright(`Penambahan akun massal selesai. ${successCount} akun berhasil ditambahkan.`) + "\n" + chalk.blackBright("Tekan Enter untuk Kembali"), serverStatus.banner || '');
    }

    // Option 3: Delete an existing session.
    if (menuOption === '3') {
      try {
        let sessionFiles = getAllFilesFromFolder(DIR_PATH_SESSION);
        let sessionList = [];

        // Load session data.
        for (let i = 0; i < sessionFiles.length; i++) {
          let sessionFile = sessionFiles[i];
          if (sessionFile) {
            let sessionJson = readJsonFile(sessionFile);
            sessionList.push({
              'name': sessionJson.username,
              'location': sessionFile
            });
          }
        }

        // If sessions exist, prompt the user to delete one.
        if (sessionList.length > 0) {
          const deleteStatus = await deleteAccount(sessionList, serverStatus.banner || '');
          if (deleteStatus === "exit") {
            process.exit();
          }
        } else {
          await form(chalk.redBright("No accounts found.") + "\n" + chalk.blackBright("Press Enter To Back"), serverStatus.banner || '');
          continue;
        }
      } catch (error) {
        await form(chalk.redBright("An error occurred.") + "\n" + chalk.blackBright("Press Enter To Back"), serverStatus.banner || '');
        continue;
      }
    }
  }
})();
