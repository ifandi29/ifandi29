import a26_0x2c1a39 from 'os';
import a26_0x521162 from 'fs';
import a26_0x188869 from 'path';
import a26_0x570da7 from 'crypto';
import a26_0x41b79b from 'chalk';
import { promisify } from 'util';
import { writeFile, readFile } from 'fs';
import { exec } from 'child_process';
import { promisified } from 'regedit';
import a26_0x3a3e6d from 'axios';
import { v4 as a26_0x29ea65 } from 'uuid';
import { ALIAS, VERSION_SC } from './konst.js';
const writeFileAsync = promisify(writeFile);
const readFileAsync = promisify(readFile);
const execPromise = promisify(exec);
const getOrdinalSuffix = _0x51d42d => {
  const _0x3659c8 = _0x51d42d % 0xa;
  const _0x28ed8b = _0x51d42d % 0x64;
  if (_0x3659c8 === 0x1 && _0x28ed8b !== 0xb) {
    return _0x51d42d + 'st';
  }
  if (_0x3659c8 === 0x2 && _0x28ed8b !== 0xc) {
    return _0x51d42d + 'nd';
  }
  if (_0x3659c8 === 0x3 && _0x28ed8b !== 0xd) {
    return _0x51d42d + 'rd';
  }
  return _0x51d42d + 'th';
};
const formatDate = _0x48d19b => {
  const _0x47a410 = new Date(Math.floor(_0x48d19b * 0x3e8));
  let _0x2449b7 = _0x47a410.getDate();
  let _0x5e3f86 = _0x47a410.getMonth() + 0x1;
  let _0x1bc713 = _0x47a410.getFullYear();
  if (_0x2449b7 < 0xa) {
    _0x2449b7 = '0' + _0x2449b7;
  }
  if (_0x5e3f86 < 0xa) {
    _0x5e3f86 = '0' + _0x5e3f86;
  }
  const _0x338ead = _0x1bc713.toString().slice(-0x2);
  return _0x2449b7 + '/' + _0x5e3f86 + '/' + _0x338ead;
};
const countdownLicense = _0x46baa5 => {
  const _0xa70b8d = Date.now();
  let _0x201a19 = Math.floor(_0x46baa5 * 0x3e8) - _0xa70b8d;
  if (_0x201a19 <= 0x0) {
    return "license Expired";
  }
  const _0x2fffc8 = Math.floor(_0x201a19 / 86400000);
  _0x201a19 %= 86400000;
  const _0x377f8d = Math.floor(_0x201a19 / 3600000);
  _0x201a19 %= 3600000;
  const _0x1c2b82 = Math.floor(_0x201a19 / 60000);
  return _0x2fffc8 + " hari " + _0x377f8d + " jam " + _0x1c2b82 + " menit";
};
const convertTimestamp = _0x4c73f7 => {
  if (_0x4c73f7 < 0x1) {
    _0x4c73f7 = 0x0;
  }
  const _0x36be5b = Math.floor(_0x4c73f7 / 0xe10);
  const _0xd255e2 = Math.floor(_0x4c73f7 % 0xe10 / 0x3c);
  const _0x2294d3 = _0x4c73f7 % 0x3c;
  const _0x25839d = _0x36be5b.toString().padStart(0x2, '0');
  const _0x5ecfdc = _0xd255e2.toString().padStart(0x2, '0');
  const _0xfd41e1 = _0x2294d3.toString().padStart(0x2, '0');
  return '' + a26_0x41b79b.magentaBright('[') + a26_0x41b79b.whiteBright(_0x25839d) + a26_0x41b79b.blackBright(':') + a26_0x41b79b.whiteBright(_0x5ecfdc) + a26_0x41b79b.blackBright(':') + a26_0x41b79b.whiteBright(_0xfd41e1) + a26_0x41b79b.magentaBright(']');
};
const getCurrentTime = () => {
  const _0x5ea734 = new Date();
  const _0x88ac1e = _0x5ea734.getHours().toString().padStart(0x2, '0');
  const _0x10bbfa = _0x5ea734.getMinutes().toString().padStart(0x2, '0');
  const _0x1b2caa = _0x5ea734.getSeconds().toString().padStart(0x2, '0');
  return '' + a26_0x41b79b.magentaBright('[') + a26_0x41b79b.whiteBright(_0x88ac1e) + a26_0x41b79b.blackBright(':') + a26_0x41b79b.whiteBright(_0x10bbfa) + a26_0x41b79b.blackBright(':') + a26_0x41b79b.whiteBright(_0x1b2caa) + a26_0x41b79b.magentaBright(']');
};
const formatNumber = _0xfd7b59 => {
  const _0x593d80 = ['', 'K', 'M', 'B', 'T', 'Q'];
  if (_0xfd7b59 < 0x3e8) {
    return _0xfd7b59.toString();
  }
  let _0x3abde8 = -0x1;
  let _0x5cc0c3 = _0xfd7b59;
  while (_0x5cc0c3 >= 0x3e8) {
    _0x5cc0c3 /= 0x3e8;
    _0x3abde8++;
  }
  if (_0x3abde8 >= _0x593d80.length) {
    const _0x13d570 = _0x3abde8 - _0x593d80.length;
    const _0x244b4c = 'abcdefghijklmnopqrstuvwxyz'[Math.floor(_0x13d570 / 'abcdefghijklmnopqrstuvwxyz'.length)];
    const _0x297162 = 'abcdefghijklmnopqrstuvwxyz'[_0x13d570 % 'abcdefghijklmnopqrstuvwxyz'.length];
    return '' + _0x5cc0c3.toFixed(0x3) + _0x244b4c + _0x297162;
  }
  return '' + _0x5cc0c3.toFixed(0x3) + _0x593d80[_0x3abde8];
};
const sha1Hash = _0x411688 => {
  const _0x353497 = a26_0x570da7.createHash('sha1');
  _0x353497.update(_0x411688);
  return _0x353497.digest("hex");
};
const validateLicense = async _0x4133e2 => {
  try {
    const _0x2324d3 = await a26_0x3a3e6d.post('https://tuyulgaple.my.id/premium/', {
      'request': ALIAS,
      'tipe': "verif",
      'userid': _0x4133e2
    });
    return _0x2324d3.data;
  } catch (_0x39bf77) {
    return {
      'code': 0x64,
      'data': null
    };
  }
};
const getWindowsProductId = async () => {
  try {
    const {
      stdout: _0x1935ea,
      stderr: _0x19f2e5
    } = await execPromise("powershell.exe \"(Get-WmiObject Win32_ComputerSystemProduct).UUID\"");
    if (_0x19f2e5) {
      return null;
    }
    const _0x2ce474 = _0x1935ea.trim();
    return _0x2ce474;
  } catch (_0x13d02c) {
    return null;
  }
};
const generateLicenseTermux = async () => {
  try {
    await execPromise("termux-keystore generate " + ALIAS + " -a RSA");
    const {
      stdout: _0x1fa8e5,
      stderr: _0x3b9b67
    } = await execPromise("termux-keystore list -d");
    if (_0x3b9b67) {
      throw new Error("Termux API not installed");
    }
    let _0x5c65ce = null;
    try {
      const _0x7841b4 = JSON.parse(_0x1fa8e5.trim());
      if (_0x7841b4.length > 0x0) {
        _0x7841b4.forEach(_0x2ab972 => {
          if (_0x2ab972.alias === ALIAS) {
            _0x5c65ce = sha1Hash(_0x2ab972.modulus);
          }
        });
      }
    } catch (_0xcd068f) {
      throw new Error("Failed parsing license data");
    }
    if (!_0x5c65ce) {
      throw new Error("Failed generating license key");
    }
    return _0x5c65ce;
  } catch (_0x2edd84) {
    throw new Error("Failed generating license: " + _0x2edd84.message);
  }
};
const getLicenseTermux = async () => {
  try {
    const {
      stdout: _0x10fd67,
      stderr: _0x53ce67
    } = await execPromise("termux-keystore list -d");
    if (_0x53ce67) {
      throw new Error("Termux API not installed");
    }
    let _0x36d9d4 = null;
    try {
      const _0x1ccd52 = JSON.parse(_0x10fd67.trim());
      if (_0x1ccd52.length > 0x0) {
        _0x1ccd52.forEach(_0x5d1da8 => {
          if (_0x5d1da8.alias === ALIAS) {
            _0x36d9d4 = sha1Hash(_0x5d1da8.modulus);
          }
        });
      }
    } catch (_0x22e210) {
      throw new Error("Failed parsing license data");
    }
    if (!_0x36d9d4) {
      _0x36d9d4 = await generateLicenseTermux();
    }
    return _0x36d9d4;
  } catch (_0x29dc6a) {
    throw new Error("Failed getting license: " + _0x29dc6a.message);
  }
};
const getRegeditProductId = async () => {
  try {
    const _0x26be59 = await promisified.list(["HKCU\\SOFTWARE\\CatizenPremium"]);
    if (_0x26be59["HKCU\\SOFTWARE\\CatizenPremium"].exists) {
      const _0x49758f = _0x26be59["HKCU\\SOFTWARE\\CatizenPremium"].values.uuid;
      if (!_0x49758f) {
        const _0x38712a = a26_0x29ea65();
        await promisified.putValue({
          "HKCU\\SOFTWARE\\CatizenPremium": {
            'uuid': {
              'value': _0x38712a,
              'type': "REG_SZ"
            }
          }
        });
        return _0x38712a;
      }
      if (_0x49758f && typeof _0x49758f.value === "string") {
        return _0x49758f.value;
      } else {
        throw new Error("Invalid UUID format in registry");
      }
    } else {
      const _0x1c7d6a = a26_0x29ea65();
      await promisified.createKey(["HKCU\\SOFTWARE\\CatizenPremium"]);
      await promisified.putValue({
        "HKCU\\SOFTWARE\\CatizenPremium": {
          'uuid': {
            'value': _0x1c7d6a,
            'type': 'REG_SZ'
          }
        }
      });
      return _0x1c7d6a;
    }
  } catch (_0x44407f) {
    throw new Error("Failed while managing registry: " + _0x44407f.message);
  }
};
const getLicenseWindows = async () => {
  try {
    const _0xf59caa = await getWindowsProductId();
    let _0x2423a7 = null;
    if (_0xf59caa) {
      _0x2423a7 = sha1Hash(_0xf59caa + '|' + ALIAS);
    } else {
      const _0x4ec6a5 = await getRegeditProductId();
      _0x2423a7 = sha1Hash(_0x4ec6a5 + '|' + ALIAS);
    }
    return _0x2423a7;
  } catch (_0xba00a5) {
    throw new Error("Failed while generating license: " + _0xba00a5.message);
  }
};
const getLinuxMachineId = async () => {
  try {
    const {
      stdout: _0x51b993,
      stderr: _0xd1115a
    } = await execPromise("hostnamectl status | grep \"Machine ID\"");
    if (_0xd1115a) {
      throw new Error("Failed to get machine ID");
    }
    const _0x101264 = _0x51b993.trim().split(':');
    if (_0x101264.length < 0x2) {
      throw new Error("Invalid machine ID format");
    }
    const _0x3a3d3e = _0x101264[0x1].trim();
    return _0x3a3d3e;
  } catch (_0x28eed4) {
    throw new Error("Failed to get machine ID: " + _0x28eed4.message);
  }
};
const getOrCreateLinuxUUID = async () => {
  const _0x55f5b9 = '/var/lib/' + ALIAS + ".txt";
  try {
    let _0x3be6f2;
    try {
      const _0x3dc39a = await readFileAsync(_0x55f5b9, "utf8");
      _0x3be6f2 = _0x3dc39a.trim();
    } catch (_0x583346) {
      _0x3be6f2 = a26_0x29ea65();
      await writeFileAsync(_0x55f5b9, _0x3be6f2, "utf-8");
    }
    return _0x3be6f2;
  } catch (_0x1a219c) {
    throw new Error("Failed while managing UUID file: " + _0x1a219c.message);
  }
};
const getLinuxProductId = async () => {
  try {
    const _0x571a94 = await getLinuxMachineId();
    const _0x47cd8f = _0x571a94 ? _0x571a94 : await getOrCreateLinuxUUID();
    return _0x47cd8f;
  } catch (_0x23c042) {
    throw new Error("Failed while managing UUID or Machine ID: " + _0x23c042.message);
  }
};
const getLicenseUbuntu = async () => {
  try {
    const _0x399f65 = await getLinuxProductId();
    const _0x553ee6 = sha1Hash(_0x399f65 + '|' + ALIAS);
    return _0x553ee6;
  } catch (_0x2ba8e2) {
    throw new Error("Failed while generating license: " + _0x2ba8e2.message);
  }
};
const getLicense = async () => {
  let _0x3ea93a = null;
  if (a26_0x2c1a39.platform() === "win32") {
    _0x3ea93a = await getLicenseWindows();
  } else {
    if (a26_0x2c1a39.platform() === "android") {
      _0x3ea93a = await getLicenseTermux();
    } else {
      if (a26_0x2c1a39.platform() === 'linux') {
        _0x3ea93a = await getLicenseUbuntu();
      } else {
        throw new Error("This program not support for " + a26_0x2c1a39.platform() + " yet");
      }
    }
  }
  return _0x3ea93a;
};
const getSessionDirectory = () => {
    // Menyimpan direktori sesi ke folder "session" di direktori kerja saat ini
    const sessionDir = a26_0x188869.join(process.cwd(), "session");
    return sessionDir;
  };
  
  const createSessionDirectory = () => {
    const sessionDirectory = getSessionDirectory();
    if (!a26_0x521162.existsSync(sessionDirectory)) {
      a26_0x521162.mkdirSync(sessionDirectory, {
        recursive: true
      });
    }
    return sessionDirectory;  // Mengembalikan path direktori sesi yang baru dibuat
  };
const runtimeServer = async () => {
  try {
    const _0x35cece = await a26_0x3a3e6d.post("https://tuyulgaple.my.id/adidoank/", {
      'sk': ALIAS,
      'vr': VERSION_SC
    });
    if (_0x35cece.data.status) {
      return {
        'status': "connect",
        'baner': _0x35cece.data.baner
      };
    } else {
      return _0x35cece.data === '' ? {
        'status': 'reconnecting',
        'baner': baner()
      } : {
        'status': "exit",
        'baner': baner()
      };
    }
  } catch (_0x4e04ad) {
    return {
      'status': 'reconnecting',
      'baner': baner()
    };
  }
};
const baner = () => {
  const _0x315d53 = "\n" + a26_0x41b79b.white("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~") + "\n" + a26_0x41b79b.blueBright("╔══╗ ╔╦╗ ╔═╦╗ ╔╦╗ ╔╗─ ╔══╗ ╔══╗ ╔═╗ ╔╗─ ╔═╗") + "\n" + a26_0x41b79b.blueBright("╚╗╔╝ ║║║ ╚╗║║ ║║║ ║║─ ║╔═╣ ║╔╗║ ║╬║ ║║─ ║╦╝") + "\n" + a26_0x41b79b.whiteBright("─║║─ ║║║ ╔╩╗║ ║║║ ║╚╗ ║╚╗║ ║╠╣║ ║╔╝ ║╚╗ ║╩") + "\n" + a26_0x41b79b.cyanBright("─╚╝─ ╚═╝ ╚══╝ ╚═╝ ╚═╝ ╚══╝ ╚╝╚╝ ╚╝─ ╚═╝ ╚═╝") + "\n" + a26_0x41b79b.whiteBright("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~") + "\n" + a26_0x41b79b.whiteBright("- skrip") + a26_0x41b79b.blueBright('[' + ALIAS + ']') + " " + a26_0x41b79b.whiteBright("Versi : " + VERSION_SC) + "\n" + a26_0x41b79b.redBright("- tidak dapat terhubung ke server") + " " + a26_0x41b79b.blueBright("tuyulgaple") + "\n";
  return _0x315d53;
};
const updateBanner = _0x3f014a => {
  const _0x402f2d = _0x3f014a.replace("╔══╗ ╔╦╗ ╔═╦╗ ╔╦╗ ╔╗─ ╔══╗ ╔══╗ ╔═╗ ╔╗─ ╔═╗\n╚╗╔╝ ║║║ ╚╗║║ ║║║ ║║─ ║╔═╣ ║╔╗║ ║╬║ ║║─ ║╦╝[37m\n─║║─ ║║║ ╔╩╗║ ║║║ ║╚╗ ║╚╗║ ║╠╣║ ║╔╝ ║╚╗ ║╩╗[36m\n─╚╝─ ╚═╝ ╚══╝ ╚═╝ ╚═╝ ╚══╝ ╚╝╚╝ ╚╝─ ╚═╝ ╚═╝[37m\n", "[34m╔══╗ ╔╦╗ ╔═╦╗ ╔╦╗ ╔╗─ ╔══╗ ╔══╗ ╔═╗ ╔╗─ ╔═╗\n[37m╚╗╔╝ ║║║ ╚╗║║ ║║║ ║║─ ║╔═╣ ║╔╗║ ║╬║ ║║─ ║╦╝\n[36m─║║─ ║║║ ╔╩╗║ ║║║ ║╚╗ ║╚╗║ ║╠╣║ ║╔╝ ║╚╗ ║╩╗\n[37m─╚╝─ ╚═╝ ╚══╝ ╚═╝ ╚═╝ ╚══╝ ╚╝╚╝ ╚╝─ ╚═╝ ╚═╝\n");
  return _0x402f2d;
};
const writeToFile = async (_0x4c3586, _0x1266e9) => {
  await writeFileAsync(_0x4c3586, _0x1266e9, 'utf-8');
};
const readJsonFile = _0x18c76b => {
  try {
    const _0x3ce9e2 = a26_0x521162.readFileSync(_0x18c76b, "utf8");
    return JSON.parse(_0x3ce9e2);
  } catch (_0x38a6c0) {
    return null;
  }
};
const deleteFile = _0x1836d8 => {
  try {
    a26_0x521162.unlinkSync(_0x1836d8);
    return {
      'status': true,
      'message': "File deleted successfully"
    };
  } catch (_0x1b332c) {
    return {
      'status': false,
      'message': "Error deleting the file"
    };
  }
};
const getAllFilesFromFolder = _0xa9376f => {
  let _0x27c787 = [];
  function _0x160fc0(_0x54be8e) {
    const _0x32d7fd = a26_0x521162.readdirSync(_0x54be8e);
    _0x32d7fd.forEach(_0x41321b => {
      const _0x321b77 = a26_0x188869.join(_0x54be8e, _0x41321b);
      const _0x3c3815 = a26_0x521162.statSync(_0x321b77);
      if (_0x3c3815 && _0x3c3815.isDirectory()) {
        _0x160fc0(_0x321b77);
      } else {
        _0x27c787.push(_0x321b77);
      }
    });
  }
  _0x160fc0(getSessionDirectory(_0xa9376f));
  return _0x27c787;
};
const groupAccounts = (_0x593e95, _0x32b879) => {
  const _0xcd7e37 = [];
  for (let _0xe83251 = 0x0; _0xe83251 < _0x593e95.length; _0xe83251 += _0x32b879) {
    _0xcd7e37.push(_0x593e95.slice(_0xe83251, _0xe83251 + _0x32b879));
  }
  return _0xcd7e37;
};
const getUserFromUrl = _0x333944 => {
  const _0x299378 = new URLSearchParams(_0x333944);
  const _0x183510 = _0x299378.get("user");
  if (!_0x183510) {
    throw new Error("Parameter 'user' tidak ditemukan di URL");
  }
  const _0x387a55 = decodeURIComponent(_0x183510);
  const _0x5b3269 = JSON.parse(_0x387a55);
  return _0x5b3269;
};
export { getOrdinalSuffix, convertTimestamp, getCurrentTime, formatNumber, validateLicense, getLicense, createSessionDirectory, getSessionDirectory, getAllFilesFromFolder, writeToFile, readJsonFile, deleteFile, runtimeServer, updateBanner, groupAccounts, getUserFromUrl, formatDate, countdownLicense };