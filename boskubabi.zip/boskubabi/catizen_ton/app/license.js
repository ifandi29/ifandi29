import chalk from 'chalk';

const License = async () => {
    // Set expiry date 1000 tahun ke depan
    const licenseData = {
        code: 200,
        data: {
            exp: Math.floor(Date.now() / 1000) + (60 * 60 * 24 * 365 * 1000) // Set expiry date 1000 tahun ke depan
        }
    };

    console.log(chalk.greenBright('License validation bypassed. You can use the application without a valid license.'));

    // Mengembalikan data lisensi yang valid
    return licenseData;
};

export default License;
